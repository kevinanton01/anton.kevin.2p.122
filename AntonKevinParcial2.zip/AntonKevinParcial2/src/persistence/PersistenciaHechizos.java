package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import model.Hechizo;
import model.LibroDeHechizos;

public interface PersistenciaHechizos {
    static void guardarHechizosCSV(LibroDeHechizos<? extends Hechizo> libro, String path){
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(path))){
            escritor.write(LibroDeHechizos.getHeaderCSV());
            escritor.write(libro.toCSV());
        } catch(IOException ex){
            System.out.println(ex.getMessage());     
        }
    }
    
    static LibroDeHechizos<Hechizo> cargarHechizosCSV(String path){
        LibroDeHechizos<Hechizo> toReturn = new LibroDeHechizos<>();
        
        try(BufferedReader lector = new BufferedReader(new FileReader(path))){            
            lector.readLine();
            String datos;
            while((datos = lector.readLine()) != null){
                toReturn.agregar(Hechizo.fromCSV(datos));
            }           
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
    
    static void serializarHechizos(LibroDeHechizos<? extends Hechizo> lista, String path){
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(lista);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    static LibroDeHechizos<Hechizo> deserializarHechizos(String path){
        LibroDeHechizos<Hechizo> toReturn = null;
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){   
            toReturn = (LibroDeHechizos<Hechizo>) entrada.readObject();     
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
  
}
