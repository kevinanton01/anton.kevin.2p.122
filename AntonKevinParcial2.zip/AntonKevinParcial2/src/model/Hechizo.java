package model;

import java.io.Serializable;
import service.CSVSerializable;

public class Hechizo implements Comparable<Hechizo>, CSVSerializable, Serializable{
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String creador;
    private Tipo tipo;

    public Hechizo(int id, String nombre, String creador, Tipo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Hechizo{" + "id=" + id + ", nombre=" + nombre + ", creador=" + creador + ", tipo=" + tipo + '}';
    }
    
    @Override
    public int compareTo(Hechizo o) {
        return Integer.compare(id, o.id);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public Tipo getTipo() {
        return tipo;
    }
    
    public static Hechizo fromCSV(String hechizosCSV){
        String[] datos = hechizosCSV.substring(0, hechizosCSV.length()).split(",");
        return new Hechizo(Integer.parseInt(datos[0]), datos[1], datos[2], Tipo.valueOf(datos[3]));    
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipo;
    }

}
