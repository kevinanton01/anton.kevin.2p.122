package model;

public enum Tipo {
    ATAQUE,
    DEFENSA,
    UTILIDAD,
    OSCURO,
    CURACION,
    ENCANTAMIENTO   
}
