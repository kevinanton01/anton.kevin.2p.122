package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import persistence.PersistenciaHechizos;
import service.CSVSerializable;
import service.Hechizable;

public class LibroDeHechizos<T extends CSVSerializable> implements Hechizable<T>, CSVSerializable<T>, Serializable, PersistenciaHechizos{
    private static final long serialVersionUID = 1L;
    private List<T> elementos = new ArrayList<>();

    @Override
    public void agregar(T elemento) {
        if (elemento == null) {
            throw new NullPointerException("Elemento nulo.");
        }
        elementos.add(elemento);
    }

    @Override
    public void eliminar(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            return;
        }
        elementos.remove(indice);
    }
   
    @Override
    public T obtener(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        return elementos.get(indice);
    }   
    
    @Override
    public Iterator<T> iterator() {
        if(!elementos.isEmpty() && elementos.get(0) instanceof Comparable){
            return iterator((Comparator<T>) Comparator.naturalOrder());
        }
        return copiarElementos().iterator(); 
    }
    public Iterator<T> iterator(Comparator<? super T> c) {    
        List<T> copia = copiarElementos();
        copia.sort(c);
        return copia.iterator();
    }
    private List<T> copiarElementos(){
        return new ArrayList<>(elementos);
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtradas = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                filtradas.add(elemento);
            }
        }
        return filtradas;
    }
    
    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T Elemento : elementos) {
            accion.accept(Elemento);
        }
    }
    
    public void ordenar(Comparator<? super T> comparador) {
        elementos.sort(comparador);
    }   

    @Override
    public String toCSV() {
        StringBuilder sb = new StringBuilder();
        for (T elemento : elementos) {
            sb.append(elemento.toCSV()).append("\n");
        }
        return sb.toString();
    }  
    
    public static String getHeaderCSV(){
        return "id,nombre,creador,tipo\n";
    }
    
    public void guardarEnArchivo(String path) {
        PersistenciaHechizos.serializarHechizos((LibroDeHechizos<? extends Hechizo>) this, path);
    }

    public LibroDeHechizos<Hechizo> cargarDesdeArchivo(String path) {
        return PersistenciaHechizos.deserializarHechizos(path);
    }
    
    public void guardarEnCSV(String path) {
        PersistenciaHechizos.guardarHechizosCSV((LibroDeHechizos<? extends Hechizo>) this, path);
    }

    public LibroDeHechizos<Hechizo> cargarDesdeCSV(String path) {
        return PersistenciaHechizos.cargarHechizosCSV(path);
    }

    
}
