package antonkevinparcial2;

import config.RutasArchivo;
import model.Hechizo;
import model.LibroDeHechizos;
import model.Tipo;

public class AntonKevinParcial2 {

    public static void main(String[] args) {
        try {
            LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>();

            libro.agregar(new Hechizo(1, "Expelliarmus", "Flitwick", Tipo.DEFENSA));
            libro.agregar(new Hechizo(2, "Alohomora", "Desconocido", Tipo.UTILIDAD));
            libro.agregar(new Hechizo(3, "Sectumsempra", "Severus Snape", Tipo.OSCURO));
            libro.agregar(new Hechizo(4, "Lumos", "Desconocido", Tipo.ENCANTAMIENTO));
            libro.agregar(new Hechizo(5, "Vulnera Sanentur", "Snape", Tipo.CURACION));
            
            // Mostrar todos los hechizos
            System.out.println("Hechizos:");
            libro.paraCadaElemento(h -> System.out.println(h));

            // Filtrar por tipo DEFENSA
            System.out.println("\nHechizos de tipo DEFENSA:");
            libro.filtrar(h -> h.getTipo() == Tipo.DEFENSA)
                 .forEach(System.out::println);

            // Filtrar por nombre que contenga "lumos"
            System.out.println("\nHechizos que contienen 'lumos':");
            libro.filtrar(h -> h.getNombre().toLowerCase().contains("lumos"))
                 .forEach(System.out::println);

            // Ordenar hechizos por ID (orden natural)
            System.out.println("\nHechizos ordenados por ID:");
            libro.ordenar((a, b) -> Integer.compare(a.getId(), b.getId()));
            libro.paraCadaElemento(h -> System.out.println(h));

            // Ordenar hechizos por nombre
            System.out.println("\nHechizos ordenados por nombre:");
            libro.ordenar((a, b) -> a.getNombre().compareTo(b.getNombre()));
            libro.paraCadaElemento(h -> System.out.println(h));

            // Guardar en archivo binario
            libro.guardarEnArchivo(RutasArchivo.getPathBinString());

            // Cargar desde archivo binario
            LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>();
            libroCargado = libroCargado.cargarDesdeArchivo(RutasArchivo.getPathBinString());

            System.out.println("\nHechizos cargados desde archivo binario:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

            // Guardar en archivo CSV
            libro.guardarEnCSV(RutasArchivo.getPathCSVString());

            // Cargar desde archivo CSV
            libroCargado = libroCargado.cargarDesdeCSV(RutasArchivo.getPathCSVString());

            System.out.println("\nHechizos cargados desde archivo CSV:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

    
