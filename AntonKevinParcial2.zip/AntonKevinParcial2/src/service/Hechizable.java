package service;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public interface Hechizable<T> extends Iterable<T>{
    void agregar(T elemento);

    void eliminar(int indice);
    
    T obtener(int indice);
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    void paraCadaElemento(Consumer<? super T> accion);
    
    default void mostrarContenidoNatural(){
        System.out.println("Contenido del Libro de hechizos:");
        this.forEach(System.out::println);
    } 
}
