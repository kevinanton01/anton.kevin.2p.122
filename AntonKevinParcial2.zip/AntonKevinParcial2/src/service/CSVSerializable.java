package service;

import java.util.List;
import java.util.function.Predicate;

public interface CSVSerializable<T>{
     String toCSV();
}
