package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivo {
    static final String BASE = "src/resources/";
    static final String FILE_CSV = "hechizos.csv";
    static final String FILE_BIN = "hechizos.bin";
 
    static Path getPathCSV(){
        return Paths.get(BASE, FILE_CSV);
    }
    
    static Path getPathBin(){
        return Paths.get(BASE, FILE_BIN);
    }
     
    static String getPathCSVString(){
        return getPathCSV().toString();
    }
    
    static String getPathBinString(){
        return getPathBin().toString();
    }    
}
